load('engine_data.mat');
datainput=engine_AFR;
