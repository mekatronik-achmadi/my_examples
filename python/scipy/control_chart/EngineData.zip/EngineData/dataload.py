#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# import modules
import scipy.io as sio

# load data
loadedmat = sio.loadmat('engine_data.mat')
datainput = loadedmat['engine_AFR']
